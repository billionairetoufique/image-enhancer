# AI Image Enhancer Website

A modern, responsive image enhancement tool website built with HTML, CSS, and JavaScript. Features a dark theme with purple/blue gradients, glassmorphism effects, and simulated AI image processing capabilities.

## 🌟 Features

### Design & UI
- **Dark Theme**: Modern dark interface with purple/blue gradient accents (#6C63FF to #4A00E0)
- **Glassmorphism Effects**: Translucent cards and UI elements with backdrop blur
- **Responsive Design**: Mobile-first approach with breakpoints for all device sizes
- **Animated Particles**: Dynamic background particle system
- **Smooth Animations**: Scroll-triggered animations and hover effects

### Core Functionality
- **Drag & Drop Upload**: Intuitive file upload with visual feedback
- **Image Processing Simulation**: Client-side image enhancement with progress tracking
- **Before/After Comparison**: Interactive slider to compare original and enhanced images
- **Download Functionality**: Save enhanced images with confetti celebration
- **File Validation**: Support for JPG, PNG, WebP formats (max 10MB)

### Image Enhancement Features
- AI Enhancement simulation (brightness, contrast, saturation)
- Noise reduction algorithms
- Super resolution upscaling
- Color correction
- Background removal simulation
- Face refinement for portraits

### Performance Optimizations
- Lazy loading for images and resources
- Service Worker for caching
- Optimized animations for low-end devices
- Resource preloading and DNS prefetching
- Memory management and cleanup

## 🚀 Quick Start

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Local web server (Python, Node.js, or any HTTP server)

### Installation

1. **Clone or download the project files**
   ```bash
   # If using git
   git clone <repository-url>
   cd image-enhancer
   
   # Or extract the provided files to a directory
   ```

2. **Start a local web server**
   
   **Using Python:**
   ```bash
   # Python 3
   python3 -m http.server 8000
   
   # Python 2
   python -m SimpleHTTPServer 8000
   ```
   
   **Using Node.js:**
   ```bash
   npx http-server -p 8000
   ```
   
   **Using PHP:**
   ```bash
   php -S localhost:8000
   ```

3. **Open in browser**
   Navigate to `http://localhost:8000` in your web browser

## 📁 Project Structure

```
image-enhancer/
├── index.html              # Main HTML file
├── css/
│   ├── styles.css          # Core styles and theme
│   ├── components.css      # Advanced component styles
│   └── responsive.css      # Responsive design rules
├── js/
│   ├── main.js            # Core functionality and UI
│   ├── image-processor.js  # Image processing algorithms
│   ├── animations.js      # Advanced animations and effects
│   └── performance.js     # Performance optimizations
├── assets/
│   └── images/            # Image assets (placeholder)
├── sw.js                  # Service Worker for caching
└── README.md             # This file
```

## 🎨 Customization

### Colors
The color scheme is defined in CSS custom properties in `css/styles.css`:

```css
:root {
    --primary-gradient: linear-gradient(135deg, #6C63FF 0%, #4A00E0 100%);
    --primary-color: #6C63FF;
    --secondary-color: #4A00E0;
    --bg-dark: #0a0a0a;
    --bg-secondary: #1a1a1a;
    /* ... more variables */
}
```

### Typography
The website uses Google Fonts (Poppins and Montserrat). You can change fonts by modifying the imports in `index.html` and updating the CSS variables.

### Animations
Animations can be disabled for performance or accessibility by adding the `reduce-animations` class to the document element or by modifying the `@media (prefers-reduced-motion: reduce)` rules.

## 🔧 Configuration

### Image Processing Settings
Modify the enhancement parameters in `js/image-processor.js`:

```javascript
// Brightness and Contrast Enhancement
const brightness = 10; // Increase brightness slightly
const contrast = 1.2;  // Increase contrast

// Color Saturation
const saturation = 1.15; // Increase saturation slightly

// Sharpening
const sharpening = 0.1;
```

### Performance Settings
Adjust performance settings in `js/performance.js`:

```javascript
// Particle count for background animation
const particleCount = 50;

// Lazy loading threshold
rootMargin: '50px 0px'

// Animation optimization for low-end devices
const isLowEndDevice = navigator.hardwareConcurrency <= 2;
```

## 📱 Browser Support

- **Chrome**: 60+
- **Firefox**: 55+
- **Safari**: 12+
- **Edge**: 79+

### Progressive Enhancement
The website uses progressive enhancement principles:
- Core functionality works without JavaScript
- Advanced features gracefully degrade on older browsers
- Fallbacks provided for modern CSS features

## 🎯 Key Features Explained

### Drag & Drop Upload
- Visual feedback during drag operations
- File type and size validation
- Error handling with user notifications
- Accessibility support with keyboard navigation

### Image Processing Simulation
The image processing is entirely client-side and simulates AI enhancement:
- **Brightness/Contrast**: Adjusts luminance and contrast ratios
- **Color Saturation**: Enhances color vibrancy
- **Noise Reduction**: Applies smoothing algorithms
- **Sharpening**: Edge enhancement for clarity
- **Super Resolution**: Upscaling with interpolation

### Comparison Slider
Interactive before/after comparison with:
- Mouse and touch support
- Smooth dragging animation
- Responsive design
- Keyboard accessibility

### Performance Features
- **Lazy Loading**: Images load as they enter viewport
- **Service Worker**: Caches resources for offline access
- **Resource Hints**: DNS prefetch and preconnect for faster loading
- **Animation Optimization**: Reduces effects on low-end devices

## 🔒 Security Considerations

- All image processing happens client-side
- No data is sent to external servers
- File validation prevents malicious uploads
- CSP headers recommended for production

## 🚀 Deployment

### Static Hosting
The website is a static site and can be deployed to:
- **Netlify**: Drag and drop the folder
- **Vercel**: Connect your repository
- **GitHub Pages**: Push to a GitHub repository
- **AWS S3**: Upload files to an S3 bucket
- **Firebase Hosting**: Use Firebase CLI

### Production Optimizations
For production deployment:

1. **Minify CSS and JavaScript**
2. **Optimize images** (use WebP format)
3. **Enable Gzip compression**
4. **Set up CDN** for faster global delivery
5. **Configure CSP headers**
6. **Enable HTTPS**

### Environment Variables
No environment variables required - the website is fully client-side.

## 🐛 Troubleshooting

### Common Issues

**Images not loading:**
- Check file format (JPG, PNG, WebP only)
- Verify file size (max 10MB)
- Ensure JavaScript is enabled

**Animations not working:**
- Check browser compatibility
- Verify JavaScript is enabled
- Check for `prefers-reduced-motion` setting

**Upload not working:**
- Ensure local server is running
- Check browser console for errors
- Verify file permissions

### Debug Mode
Enable debug mode by adding `?debug=true` to the URL for additional console logging.

## 📄 License

This project is provided as-is for educational and demonstration purposes.

## 🤝 Contributing

This is a demonstration project. For improvements:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For questions or issues:
- Check the browser console for error messages
- Verify all files are present and properly linked
- Ensure you're running a local server (not opening files directly)

---

**Built with ❤️ using modern web technologies**

