// Advanced Animations and Special Effects

// Initialize animations when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeAnimations();
});

function initializeAnimations() {
    setupIntersectionObserver();
    setupMouseTracker();
    setupParallaxEffects();
    setupTypewriterEffect();
    setupCounterAnimations();
    setupMorphingShapes();
    setupGlowEffects();
    setupFloatingElements();
}

// Intersection Observer for scroll animations
function setupIntersectionObserver() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                
                // Trigger specific animations based on element type
                if (entry.target.classList.contains('feature-card')) {
                    animateFeatureCard(entry.target);
                } else if (entry.target.classList.contains('step')) {
                    animateStep(entry.target);
                } else if (entry.target.classList.contains('pricing-card')) {
                    animatePricingCard(entry.target);
                }
            }
        });
    }, observerOptions);

    // Observe elements
    const elementsToAnimate = document.querySelectorAll(
        '.feature-card, .step, .pricing-card, .testimonial-slide, .upload-area'
    );
    
    elementsToAnimate.forEach(el => {
        el.classList.add('animate-on-scroll');
        observer.observe(el);
    });
}

// Mouse tracking for interactive effects
function setupMouseTracker() {
    let mouseX = 0;
    let mouseY = 0;

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        updateMouseEffects(mouseX, mouseY);
    });

    // Create cursor follower
    createCursorFollower();
}

function updateMouseEffects(x, y) {
    // Update CSS custom properties for mouse position
    document.documentElement.style.setProperty('--mouse-x', x + 'px');
    document.documentElement.style.setProperty('--mouse-y', y + 'px');
    
    // Update card hover effects
    const cards = document.querySelectorAll('.card-hover');
    cards.forEach(card => {
        const rect = card.getBoundingClientRect();
        const cardX = ((x - rect.left) / rect.width) * 100;
        const cardY = ((y - rect.top) / rect.height) * 100;
        
        card.style.setProperty('--mouse-x', cardX + '%');
        card.style.setProperty('--mouse-y', cardY + '%');
    });
}

function createCursorFollower() {
    const cursor = document.createElement('div');
    cursor.className = 'cursor-follower';
    cursor.style.cssText = `
        position: fixed;
        width: 20px;
        height: 20px;
        background: radial-gradient(circle, rgba(108, 99, 255, 0.8) 0%, transparent 70%);
        border-radius: 50%;
        pointer-events: none;
        z-index: 9999;
        transition: transform 0.1s ease;
        mix-blend-mode: screen;
    `;
    
    document.body.appendChild(cursor);
    
    document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX - 10 + 'px';
        cursor.style.top = e.clientY - 10 + 'px';
    });
    
    // Hide on touch devices
    if ('ontouchstart' in window) {
        cursor.style.display = 'none';
    }
}

// Parallax effects
function setupParallaxEffects() {
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.parallax');
        
        parallaxElements.forEach(element => {
            const speed = element.dataset.speed || 0.5;
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
        
        // Parallax for hero background
        const heroBackground = document.querySelector('.hero-background');
        if (heroBackground) {
            const yPos = scrolled * 0.3;
            heroBackground.style.transform = `translateY(${yPos}px)`;
        }
    });
}

// Typewriter effect for hero title
function setupTypewriterEffect() {
    const heroTitle = document.querySelector('.hero-title');
    if (!heroTitle) return;
    
    const text = heroTitle.textContent;
    heroTitle.textContent = '';
    heroTitle.style.borderRight = '2px solid #6C63FF';
    
    let i = 0;
    const typeWriter = () => {
        if (i < text.length) {
            heroTitle.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        } else {
            // Remove cursor after typing
            setTimeout(() => {
                heroTitle.style.borderRight = 'none';
            }, 1000);
        }
    };
    
    // Start typewriter effect after a delay
    setTimeout(typeWriter, 1000);
}

// Counter animations for statistics
function setupCounterAnimations() {
    const counters = document.querySelectorAll('.counter');
    
    counters.forEach(counter => {
        const target = parseInt(counter.dataset.target);
        const duration = parseInt(counter.dataset.duration) || 2000;
        const increment = target / (duration / 16); // 60fps
        
        let current = 0;
        const updateCounter = () => {
            current += increment;
            if (current < target) {
                counter.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };
        
        // Start animation when element is visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(counter);
    });
}

// Morphing shapes animation
function setupMorphingShapes() {
    const shapes = document.querySelectorAll('.morphing-shape');
    
    shapes.forEach(shape => {
        let morphState = 0;
        const morphSpeed = 0.02;
        
        const animate = () => {
            morphState += morphSpeed;
            const scale = 1 + Math.sin(morphState) * 0.1;
            const rotation = Math.sin(morphState * 0.5) * 10;
            
            shape.style.transform = `scale(${scale}) rotate(${rotation}deg)`;
            requestAnimationFrame(animate);
        };
        
        animate();
    });
}

// Glow effects on hover
function setupGlowEffects() {
    const glowElements = document.querySelectorAll('.glow-on-hover');
    
    glowElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            element.style.boxShadow = '0 0 30px rgba(108, 99, 255, 0.6)';
            element.style.transform = 'scale(1.05)';
        });
        
        element.addEventListener('mouseleave', () => {
            element.style.boxShadow = '';
            element.style.transform = '';
        });
    });
}

// Floating elements animation
function setupFloatingElements() {
    const floatingElements = document.querySelectorAll('.floating-element');
    
    floatingElements.forEach((element, index) => {
        const amplitude = 20 + Math.random() * 10;
        const frequency = 0.01 + Math.random() * 0.01;
        const phase = index * Math.PI / 4;
        
        let time = 0;
        const animate = () => {
            time += frequency;
            const y = Math.sin(time + phase) * amplitude;
            element.style.transform = `translateY(${y}px)`;
            requestAnimationFrame(animate);
        };
        
        animate();
    });
}

// Specific animation functions
function animateFeatureCard(card) {
    const icon = card.querySelector('.feature-icon');
    const title = card.querySelector('.feature-title');
    const description = card.querySelector('.feature-description');
    
    // Stagger animations
    setTimeout(() => {
        if (icon) icon.style.animation = 'bounceIn 0.6s ease forwards';
    }, 100);
    
    setTimeout(() => {
        if (title) title.style.animation = 'slideInUp 0.6s ease forwards';
    }, 300);
    
    setTimeout(() => {
        if (description) description.style.animation = 'fadeInUp 0.6s ease forwards';
    }, 500);
}

function animateStep(step) {
    const number = step.querySelector('.step-number');
    const content = step.querySelector('.step-content');
    
    if (number) {
        number.style.animation = 'zoomIn 0.6s ease forwards';
    }
    
    setTimeout(() => {
        if (content) content.style.animation = 'slideInUp 0.6s ease forwards';
    }, 200);
}

function animatePricingCard(card) {
    card.style.animation = 'slideInUp 0.8s ease forwards';
    
    // Animate pricing elements
    const price = card.querySelector('.plan-price');
    const features = card.querySelectorAll('.plan-features li');
    
    setTimeout(() => {
        if (price) price.style.animation = 'bounceIn 0.6s ease forwards';
    }, 300);
    
    features.forEach((feature, index) => {
        setTimeout(() => {
            feature.style.animation = 'slideInLeft 0.4s ease forwards';
        }, 500 + index * 100);
    });
}

// Advanced particle system
function createAdvancedParticleSystem() {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    canvas.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
        opacity: 0.6;
    `;
    
    document.body.appendChild(canvas);
    
    const particles = [];
    const particleCount = 50;
    
    // Resize canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    
    // Particle class
    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.vx = (Math.random() - 0.5) * 0.5;
            this.vy = (Math.random() - 0.5) * 0.5;
            this.size = Math.random() * 3 + 1;
            this.opacity = Math.random() * 0.5 + 0.2;
            this.color = `rgba(108, 99, 255, ${this.opacity})`;
        }
        
        update() {
            this.x += this.vx;
            this.y += this.vy;
            
            // Wrap around edges
            if (this.x < 0) this.x = canvas.width;
            if (this.x > canvas.width) this.x = 0;
            if (this.y < 0) this.y = canvas.height;
            if (this.y > canvas.height) this.y = 0;
        }
        
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.fill();
        }
    }
    
    // Initialize particles
    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
    }
    
    // Animation loop
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        particles.forEach(particle => {
            particle.update();
            particle.draw();
        });
        
        // Draw connections
        drawConnections();
        
        requestAnimationFrame(animate);
    }
    
    function drawConnections() {
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < 100) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = `rgba(108, 99, 255, ${0.1 * (1 - distance / 100)})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        }
    }
    
    animate();
}

// Text reveal animation
function setupTextRevealAnimation() {
    const textElements = document.querySelectorAll('.text-reveal');
    
    textElements.forEach(element => {
        const text = element.textContent;
        element.innerHTML = '';
        
        // Wrap each character in a span
        for (let i = 0; i < text.length; i++) {
            const span = document.createElement('span');
            span.textContent = text[i] === ' ' ? '\u00A0' : text[i];
            span.style.cssText = `
                display: inline-block;
                opacity: 0;
                transform: translateY(20px);
                transition: all 0.3s ease;
                transition-delay: ${i * 0.05}s;
            `;
            element.appendChild(span);
        }
        
        // Animate when visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const spans = entry.target.querySelectorAll('span');
                    spans.forEach(span => {
                        span.style.opacity = '1';
                        span.style.transform = 'translateY(0)';
                    });
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(element);
    });
}

// Magnetic button effect
function setupMagneticButtons() {
    const magneticButtons = document.querySelectorAll('.magnetic-btn');
    
    magneticButtons.forEach(button => {
        button.addEventListener('mousemove', (e) => {
            const rect = button.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            
            const distance = Math.sqrt(x * x + y * y);
            const maxDistance = 50;
            
            if (distance < maxDistance) {
                const strength = (maxDistance - distance) / maxDistance;
                const moveX = x * strength * 0.3;
                const moveY = y * strength * 0.3;
                
                button.style.transform = `translate(${moveX}px, ${moveY}px)`;
            }
        });
        
        button.addEventListener('mouseleave', () => {
            button.style.transform = '';
        });
    });
}

// Liquid button effect
function setupLiquidButtons() {
    const liquidButtons = document.querySelectorAll('.liquid-btn');
    
    liquidButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('div');
            ripple.style.cssText = `
                position: absolute;
                width: 0;
                height: 0;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                left: ${x}px;
                top: ${y}px;
                transform: translate(-50%, -50%);
                animation: liquidRipple 0.6s ease-out forwards;
                pointer-events: none;
            `;
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
}

// Add CSS animations
const animationStyles = document.createElement('style');
animationStyles.textContent = `
    @keyframes bounceIn {
        0% { transform: scale(0.3); opacity: 0; }
        50% { transform: scale(1.05); }
        70% { transform: scale(0.9); }
        100% { transform: scale(1); opacity: 1; }
    }
    
    @keyframes slideInUp {
        0% { transform: translateY(30px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
    
    @keyframes slideInLeft {
        0% { transform: translateX(-30px); opacity: 0; }
        100% { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeInUp {
        0% { transform: translateY(20px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
    
    @keyframes zoomIn {
        0% { transform: scale(0); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
    }
    
    @keyframes liquidRipple {
        0% { width: 0; height: 0; opacity: 1; }
        100% { width: 300px; height: 300px; opacity: 0; }
    }
    
    .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.6s ease;
    }
    
    .animate-on-scroll.animate-in {
        opacity: 1;
        transform: translateY(0);
    }
    
    .magnetic-btn {
        transition: transform 0.3s ease;
    }
    
    .liquid-btn {
        position: relative;
        overflow: hidden;
    }
`;

document.head.appendChild(animationStyles);

// Initialize advanced effects
setTimeout(() => {
    createAdvancedParticleSystem();
    setupTextRevealAnimation();
    setupMagneticButtons();
    setupLiquidButtons();
}, 1000);

