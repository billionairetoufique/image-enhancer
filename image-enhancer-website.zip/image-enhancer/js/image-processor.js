// Image Processing Functionality

// Process image with simulated AI enhancement
function processImage() {
    if (!currentImage || isProcessing) return;
    
    isProcessing = true;
    showProcessingState();
    
    // Simulate processing with progress updates
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += Math.random() * 15 + 5; // Random progress increments
        if (progress > 100) progress = 100;
        
        updateProgress(progress);
        
        if (progress >= 100) {
            clearInterval(progressInterval);
            setTimeout(() => {
                completeProcessing();
            }, 500);
        }
    }, 200);
}

function showProcessingState() {
    const imagePreview = document.getElementById('image-preview');
    const processingState = document.getElementById('processing-state');
    
    if (imagePreview && processingState) {
        imagePreview.style.display = 'none';
        processingState.style.display = 'block';
        
        // Scroll to processing state
        processingState.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function updateProgress(percentage) {
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');
    
    if (progressFill) {
        progressFill.style.width = percentage + '%';
    }
    
    if (progressText) {
        progressText.textContent = Math.round(percentage) + '%';
    }
}

function completeProcessing() {
    // Generate enhanced image
    generateEnhancedImage(currentImage)
        .then(enhancedImageData => {
            processedImage = enhancedImageData;
            showResults();
            isProcessing = false;
        })
        .catch(error => {
            console.error('Error processing image:', error);
            showNotification('Error processing image. Please try again.', 'error');
            resetUpload();
            isProcessing = false;
        });
}

function generateEnhancedImage(originalImageData) {
    return new Promise((resolve, reject) => {
        try {
            const img = new Image();
            img.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                
                // Set canvas size
                canvas.width = img.width;
                canvas.height = img.height;
                
                // Draw original image
                ctx.drawImage(img, 0, 0);
                
                // Get image data
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imageData.data;
                
                // Apply enhancement filters
                enhanceImage(data);
                
                // Put enhanced data back
                ctx.putImageData(imageData, 0, 0);
                
                // Convert to data URL
                const enhancedDataUrl = canvas.toDataURL('image/jpeg', 0.95);
                resolve(enhancedDataUrl);
            };
            
            img.onerror = function() {
                reject(new Error('Failed to load image'));
            };
            
            img.src = originalImageData;
        } catch (error) {
            reject(error);
        }
    });
}

function enhanceImage(data) {
    // Apply multiple enhancement filters
    
    // 1. Brightness and Contrast Enhancement
    const brightness = 10; // Increase brightness slightly
    const contrast = 1.2;  // Increase contrast
    
    // 2. Color Saturation
    const saturation = 1.15; // Increase saturation slightly
    
    // 3. Sharpening (simplified)
    const sharpening = 0.1;
    
    for (let i = 0; i < data.length; i += 4) {
        let r = data[i];
        let g = data[i + 1];
        let b = data[i + 2];
        
        // Apply brightness
        r += brightness;
        g += brightness;
        b += brightness;
        
        // Apply contrast
        r = ((r - 128) * contrast) + 128;
        g = ((g - 128) * contrast) + 128;
        b = ((b - 128) * contrast) + 128;
        
        // Apply saturation
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        r = gray + saturation * (r - gray);
        g = gray + saturation * (g - gray);
        b = gray + saturation * (b - gray);
        
        // Apply sharpening (simplified edge enhancement)
        if (i > 4 && i < data.length - 4) {
            const prevR = data[i - 4];
            const nextR = data[i + 4];
            r += sharpening * (2 * r - prevR - nextR);
            
            const prevG = data[i - 3];
            const nextG = data[i + 5];
            g += sharpening * (2 * g - prevG - nextG);
            
            const prevB = data[i - 2];
            const nextB = data[i + 6];
            b += sharpening * (2 * b - prevB - nextB);
        }
        
        // Clamp values
        data[i] = Math.max(0, Math.min(255, r));
        data[i + 1] = Math.max(0, Math.min(255, g));
        data[i + 2] = Math.max(0, Math.min(255, b));
    }
    
    // Apply noise reduction (simplified)
    applyNoiseReduction(data);
}

function applyNoiseReduction(data) {
    // Simple noise reduction using a basic smoothing filter
    const width = Math.sqrt(data.length / 4); // Approximate width
    const smoothingFactor = 0.1;
    
    for (let i = 0; i < data.length; i += 4) {
        if (i > width * 4 && i < data.length - width * 4) {
            // Average with neighboring pixels
            const avgR = (data[i] + data[i - 4] + data[i + 4] + data[i - width * 4] + data[i + width * 4]) / 5;
            const avgG = (data[i + 1] + data[i - 3] + data[i + 5] + data[i - width * 4 + 1] + data[i + width * 4 + 1]) / 5;
            const avgB = (data[i + 2] + data[i - 2] + data[i + 6] + data[i - width * 4 + 2] + data[i + width * 4 + 2]) / 5;
            
            // Blend with original
            data[i] = data[i] * (1 - smoothingFactor) + avgR * smoothingFactor;
            data[i + 1] = data[i + 1] * (1 - smoothingFactor) + avgG * smoothingFactor;
            data[i + 2] = data[i + 2] * (1 - smoothingFactor) + avgB * smoothingFactor;
        }
    }
}

function showResults() {
    const processingState = document.getElementById('processing-state');
    const resultsDisplay = document.getElementById('results-display');
    const beforeImage = document.getElementById('before-image');
    const afterImage = document.getElementById('after-image');
    
    if (processingState && resultsDisplay && beforeImage && afterImage) {
        // Hide processing state
        processingState.style.display = 'none';
        
        // Set up comparison images
        beforeImage.src = currentImage;
        afterImage.src = processedImage;
        
        // Show results
        resultsDisplay.style.display = 'block';
        
        // Scroll to results
        resultsDisplay.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Initialize comparison slider
        initializeComparisonSlider();
    }
}

function initializeComparisonSlider() {
    const slider = document.getElementById('comparison-slider');
    const afterImage = slider.querySelector('.after-image');
    const handle = document.getElementById('slider-handle');
    
    if (afterImage && handle) {
        // Set initial position (50%)
        afterImage.style.width = '50%';
        handle.style.left = '50%';
    }
}

function downloadImage() {
    if (!processedImage) {
        showNotification('No processed image available', 'error');
        return;
    }
    
    try {
        // Create download link
        const link = document.createElement('a');
        link.download = 'enhanced-image-' + Date.now() + '.jpg';
        link.href = processedImage;
        
        // Trigger download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Show success notification with confetti
        showNotification('Image downloaded successfully!', 'success');
        triggerConfetti();
        
    } catch (error) {
        console.error('Download error:', error);
        showNotification('Error downloading image', 'error');
    }
}

function triggerConfetti() {
    const confettiContainer = document.getElementById('confetti-container');
    if (!confettiContainer) return;
    
    // Create confetti pieces
    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            createConfetti(confettiContainer);
        }, i * 50);
    }
}

function createConfetti(container) {
    const confetti = document.createElement('div');
    confetti.className = 'confetti';
    
    // Random properties
    const colors = ['#6C63FF', '#4A00E0', '#8B5CF6', '#3B82F6', '#10B981', '#F59E0B'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    const left = Math.random() * 100;
    const animationDuration = Math.random() * 2 + 2;
    const size = Math.random() * 8 + 4;
    
    confetti.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        left: ${left}%;
        top: -10px;
        border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
        animation: confetti-fall ${animationDuration}s linear forwards;
        z-index: 9999;
    `;
    
    container.appendChild(confetti);
    
    // Remove confetti after animation
    setTimeout(() => {
        if (confetti.parentNode) {
            confetti.parentNode.removeChild(confetti);
        }
    }, animationDuration * 1000);
}

// Advanced image processing functions

function applyColorCorrection(data) {
    // Auto color correction algorithm
    let rSum = 0, gSum = 0, bSum = 0;
    let pixelCount = data.length / 4;
    
    // Calculate average color values
    for (let i = 0; i < data.length; i += 4) {
        rSum += data[i];
        gSum += data[i + 1];
        bSum += data[i + 2];
    }
    
    const rAvg = rSum / pixelCount;
    const gAvg = gSum / pixelCount;
    const bAvg = bSum / pixelCount;
    
    // Calculate correction factors
    const grayTarget = 128;
    const rCorrection = grayTarget / rAvg;
    const gCorrection = grayTarget / gAvg;
    const bCorrection = grayTarget / bAvg;
    
    // Apply correction
    for (let i = 0; i < data.length; i += 4) {
        data[i] = Math.min(255, data[i] * rCorrection * 0.8 + data[i] * 0.2);
        data[i + 1] = Math.min(255, data[i + 1] * gCorrection * 0.8 + data[i + 1] * 0.2);
        data[i + 2] = Math.min(255, data[i + 2] * bCorrection * 0.8 + data[i + 2] * 0.2);
    }
}

function applySuperResolution(canvas, ctx, scaleFactor = 1.5) {
    // Simulate super resolution by upscaling with interpolation
    const originalWidth = canvas.width;
    const originalHeight = canvas.height;
    const newWidth = Math.floor(originalWidth * scaleFactor);
    const newHeight = Math.floor(originalHeight * scaleFactor);
    
    // Get original image data
    const originalImageData = ctx.getImageData(0, 0, originalWidth, originalHeight);
    
    // Resize canvas
    canvas.width = newWidth;
    canvas.height = newHeight;
    
    // Use bicubic interpolation (simplified)
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    
    // Create temporary canvas for original image
    const tempCanvas = document.createElement('canvas');
    const tempCtx = tempCanvas.getContext('2d');
    tempCanvas.width = originalWidth;
    tempCanvas.height = originalHeight;
    tempCtx.putImageData(originalImageData, 0, 0);
    
    // Draw upscaled image
    ctx.drawImage(tempCanvas, 0, 0, originalWidth, originalHeight, 0, 0, newWidth, newHeight);
}

function applyFaceRefinement(data, width, height) {
    // Simplified face refinement - smooth skin tones
    for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
            const i = (y * width + x) * 4;
            const r = data[i];
            const g = data[i + 1];
            const b = data[i + 2];
            
            // Detect skin tones (simplified)
            if (isSkinTone(r, g, b)) {
                // Apply gentle smoothing
                if (x > 0 && x < width - 1 && y > 0 && y < height - 1) {
                    const smoothingFactor = 0.3;
                    
                    // Average with surrounding pixels
                    const neighbors = [
                        ((y - 1) * width + (x - 1)) * 4,
                        ((y - 1) * width + x) * 4,
                        ((y - 1) * width + (x + 1)) * 4,
                        (y * width + (x - 1)) * 4,
                        (y * width + (x + 1)) * 4,
                        ((y + 1) * width + (x - 1)) * 4,
                        ((y + 1) * width + x) * 4,
                        ((y + 1) * width + (x + 1)) * 4
                    ];
                    
                    let avgR = r, avgG = g, avgB = b;
                    let validNeighbors = 1;
                    
                    neighbors.forEach(ni => {
                        if (ni >= 0 && ni < data.length - 2) {
                            avgR += data[ni];
                            avgG += data[ni + 1];
                            avgB += data[ni + 2];
                            validNeighbors++;
                        }
                    });
                    
                    avgR /= validNeighbors;
                    avgG /= validNeighbors;
                    avgB /= validNeighbors;
                    
                    // Blend with original
                    data[i] = r * (1 - smoothingFactor) + avgR * smoothingFactor;
                    data[i + 1] = g * (1 - smoothingFactor) + avgG * smoothingFactor;
                    data[i + 2] = b * (1 - smoothingFactor) + avgB * smoothingFactor;
                }
            }
        }
    }
}

function isSkinTone(r, g, b) {
    // Simple skin tone detection
    return (r > 95 && g > 40 && b > 20 && 
            Math.max(r, g, b) - Math.min(r, g, b) > 15 &&
            Math.abs(r - g) > 15 && r > g && r > b);
}

// Background removal simulation (simplified)
function simulateBackgroundRemoval(data, width, height) {
    // This is a very simplified background removal
    // In reality, this would require complex AI models
    
    // Find edges using simple edge detection
    const edges = detectEdges(data, width, height);
    
    // Create a simple mask based on color similarity
    const mask = createSimpleMask(data, width, height);
    
    // Apply mask to create transparency effect
    for (let i = 0; i < data.length; i += 4) {
        const pixelIndex = i / 4;
        if (mask[pixelIndex] < 0.5) {
            // Make background semi-transparent
            data[i + 3] = data[i + 3] * 0.3; // Alpha channel
        }
    }
}

function detectEdges(data, width, height) {
    const edges = new Array(width * height).fill(0);
    
    for (let y = 1; y < height - 1; y++) {
        for (let x = 1; x < width - 1; x++) {
            const i = (y * width + x) * 4;
            
            // Sobel edge detection (simplified)
            const gx = -data[i - 4] + data[i + 4] - 2 * data[i - width * 4] + 2 * data[i + width * 4] - data[i - width * 4 - 4] + data[i - width * 4 + 4];
            const gy = -data[i - width * 4] - 2 * data[i] - data[i + width * 4] + data[i - width * 4] + 2 * data[i] + data[i + width * 4];
            
            const magnitude = Math.sqrt(gx * gx + gy * gy);
            edges[y * width + x] = magnitude;
        }
    }
    
    return edges;
}

function createSimpleMask(data, width, height) {
    const mask = new Array(width * height).fill(1);
    
    // Simple background detection based on corner colors
    const cornerSamples = [
        data[0], data[1], data[2], // Top-left
        data[(width - 1) * 4], data[(width - 1) * 4 + 1], data[(width - 1) * 4 + 2], // Top-right
        data[((height - 1) * width) * 4], data[((height - 1) * width) * 4 + 1], data[((height - 1) * width) * 4 + 2], // Bottom-left
        data[((height - 1) * width + width - 1) * 4], data[((height - 1) * width + width - 1) * 4 + 1], data[((height - 1) * width + width - 1) * 4 + 2] // Bottom-right
    ];
    
    // Calculate average background color
    let avgR = 0, avgG = 0, avgB = 0;
    for (let i = 0; i < cornerSamples.length; i += 3) {
        avgR += cornerSamples[i];
        avgG += cornerSamples[i + 1];
        avgB += cornerSamples[i + 2];
    }
    avgR /= 4; avgG /= 4; avgB /= 4;
    
    // Create mask based on color similarity to background
    for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        
        const colorDistance = Math.sqrt(
            (r - avgR) * (r - avgR) +
            (g - avgG) * (g - avgG) +
            (b - avgB) * (b - avgB)
        );
        
        const pixelIndex = i / 4;
        mask[pixelIndex] = colorDistance > 50 ? 1 : 0; // Threshold for background
    }
    
    return mask;
}

