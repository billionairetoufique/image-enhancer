// Performance Optimization Module

// Initialize performance optimizations
document.addEventListener('DOMContentLoaded', function() {
    initializePerformanceOptimizations();
});

function initializePerformanceOptimizations() {
    setupLazyLoading();
    setupImageOptimization();
    setupResourcePreloading();
    setupServiceWorker();
    setupPerformanceMonitoring();
    optimizeAnimations();
    setupIntersectionObserverPolyfill();
    optimizeScrollPerformance();
    setupCriticalResourceHints();
}

// Lazy loading implementation
function setupLazyLoading() {
    // Lazy load images
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            });
        }, {
            rootMargin: '50px 0px',
            threshold: 0.01
        });
        
        lazyImages.forEach(img => imageObserver.observe(img));
    } else {
        // Fallback for browsers without IntersectionObserver
        lazyImages.forEach(img => {
            img.src = img.dataset.src;
            img.classList.remove('lazy');
            img.classList.add('loaded');
        });
    }
    
    // Lazy load background images
    const lazyBackgrounds = document.querySelectorAll('[data-bg]');
    
    if ('IntersectionObserver' in window) {
        const bgObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const element = entry.target;
                    element.style.backgroundImage = `url(${element.dataset.bg})`;
                    element.classList.add('bg-loaded');
                    observer.unobserve(element);
                }
            });
        });
        
        lazyBackgrounds.forEach(bg => bgObserver.observe(bg));
    }
}

// Image optimization
function setupImageOptimization() {
    // WebP support detection
    function supportsWebP() {
        return new Promise(resolve => {
            const webP = new Image();
            webP.onload = webP.onerror = () => resolve(webP.height === 2);
            webP.src = 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA';
        });
    }
    
    // Replace images with WebP versions if supported
    supportsWebP().then(supported => {
        if (supported) {
            const images = document.querySelectorAll('img[data-webp]');
            images.forEach(img => {
                img.src = img.dataset.webp;
            });
        }
    });
    
    // Responsive image loading based on device pixel ratio
    function loadResponsiveImages() {
        const pixelRatio = window.devicePixelRatio || 1;
        const responsiveImages = document.querySelectorAll('img[data-src-1x][data-src-2x]');
        
        responsiveImages.forEach(img => {
            const src = pixelRatio > 1.5 ? img.dataset.src2x : img.dataset.src1x;
            if (img.dataset.src) {
                img.dataset.src = src;
            } else {
                img.src = src;
            }
        });
    }
    
    loadResponsiveImages();
}

// Resource preloading
function setupResourcePreloading() {
    // Preload critical CSS
    const criticalCSS = [
        'css/styles.css',
        'css/components.css'
    ];
    
    criticalCSS.forEach(href => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'style';
        link.href = href;
        link.onload = function() {
            this.onload = null;
            this.rel = 'stylesheet';
        };
        document.head.appendChild(link);
    });
    
    // Preload important fonts
    const fonts = [
        'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap',
        'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap'
    ];
    
    fonts.forEach(href => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'style';
        link.href = href;
        document.head.appendChild(link);
    });
    
    // Preload next section images on hover
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('mouseenter', () => {
            const targetId = link.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                const images = targetSection.querySelectorAll('img[data-src]');
                images.forEach(img => {
                    if (!img.src) {
                        img.src = img.dataset.src;
                    }
                });
            }
        });
    });
}

// Service Worker for caching
function setupServiceWorker() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js')
                .then(registration => {
                    console.log('SW registered: ', registration);
                })
                .catch(registrationError => {
                    console.log('SW registration failed: ', registrationError);
                });
        });
    }
}

// Performance monitoring
function setupPerformanceMonitoring() {
    // Monitor Core Web Vitals
    if ('PerformanceObserver' in window) {
        // Largest Contentful Paint
        new PerformanceObserver((entryList) => {
            for (const entry of entryList.getEntries()) {
                console.log('LCP:', entry.startTime);
            }
        }).observe({ entryTypes: ['largest-contentful-paint'] });
        
        // First Input Delay
        new PerformanceObserver((entryList) => {
            for (const entry of entryList.getEntries()) {
                console.log('FID:', entry.processingStart - entry.startTime);
            }
        }).observe({ entryTypes: ['first-input'] });
        
        // Cumulative Layout Shift
        new PerformanceObserver((entryList) => {
            for (const entry of entryList.getEntries()) {
                if (!entry.hadRecentInput) {
                    console.log('CLS:', entry.value);
                }
            }
        }).observe({ entryTypes: ['layout-shift'] });
    }
    
    // Monitor resource loading
    window.addEventListener('load', () => {
        const perfData = performance.getEntriesByType('navigation')[0];
        console.log('Page Load Time:', perfData.loadEventEnd - perfData.fetchStart);
        console.log('DOM Content Loaded:', perfData.domContentLoadedEventEnd - perfData.fetchStart);
    });
}

// Animation optimization
function optimizeAnimations() {
    // Reduce animations on low-end devices
    const isLowEndDevice = navigator.hardwareConcurrency <= 2 || 
                          navigator.deviceMemory <= 2 ||
                          /Android.*Chrome\/[.0-9]*\s/.test(navigator.userAgent);
    
    if (isLowEndDevice) {
        document.documentElement.classList.add('reduce-animations');
        
        // Disable particle effects on low-end devices
        const particleContainers = document.querySelectorAll('.particles-container');
        particleContainers.forEach(container => {
            container.style.display = 'none';
        });
    }
    
    // Use requestAnimationFrame for smooth animations
    let ticking = false;
    
    function updateAnimations() {
        // Update scroll-based animations
        updateScrollAnimations();
        ticking = false;
    }
    
    window.addEventListener('scroll', () => {
        if (!ticking) {
            requestAnimationFrame(updateAnimations);
            ticking = true;
        }
    });
    
    // Pause animations when tab is not visible
    document.addEventListener('visibilitychange', () => {
        const animations = document.querySelectorAll('.animated');
        if (document.hidden) {
            animations.forEach(el => el.style.animationPlayState = 'paused');
        } else {
            animations.forEach(el => el.style.animationPlayState = 'running');
        }
    });
}

// IntersectionObserver polyfill for older browsers
function setupIntersectionObserverPolyfill() {
    if (!('IntersectionObserver' in window)) {
        // Simple fallback for IntersectionObserver
        window.IntersectionObserver = class {
            constructor(callback, options = {}) {
                this.callback = callback;
                this.options = options;
                this.elements = new Set();
            }
            
            observe(element) {
                this.elements.add(element);
                // Immediately trigger callback for fallback
                this.callback([{
                    target: element,
                    isIntersecting: true
                }], this);
            }
            
            unobserve(element) {
                this.elements.delete(element);
            }
            
            disconnect() {
                this.elements.clear();
            }
        };
    }
}

// Scroll performance optimization
function optimizeScrollPerformance() {
    let scrollTimer = null;
    
    // Throttle scroll events
    function throttleScroll(callback, delay = 16) {
        let lastCall = 0;
        return function(...args) {
            const now = Date.now();
            if (now - lastCall >= delay) {
                lastCall = now;
                callback.apply(this, args);
            }
        };
    }
    
    // Optimize scroll-based animations
    const optimizedScrollHandler = throttleScroll(() => {
        updateScrollIndicator();
        updateParallaxElements();
    });
    
    window.addEventListener('scroll', optimizedScrollHandler, { passive: true });
    
    // Add scroll end detection
    window.addEventListener('scroll', () => {
        clearTimeout(scrollTimer);
        document.body.classList.add('scrolling');
        
        scrollTimer = setTimeout(() => {
            document.body.classList.remove('scrolling');
        }, 150);
    }, { passive: true });
}

function updateScrollAnimations() {
    const scrollTop = window.pageYOffset;
    const windowHeight = window.innerHeight;
    
    // Update elements that need scroll-based updates
    const scrollElements = document.querySelectorAll('[data-scroll]');
    scrollElements.forEach(element => {
        const elementTop = element.offsetTop;
        const elementHeight = element.offsetHeight;
        
        if (scrollTop + windowHeight > elementTop && scrollTop < elementTop + elementHeight) {
            const progress = (scrollTop + windowHeight - elementTop) / (windowHeight + elementHeight);
            element.style.setProperty('--scroll-progress', progress);
        }
    });
}

function updateParallaxElements() {
    const scrolled = window.pageYOffset;
    const parallaxElements = document.querySelectorAll('[data-parallax]');
    
    parallaxElements.forEach(element => {
        const speed = parseFloat(element.dataset.parallax) || 0.5;
        const yPos = -(scrolled * speed);
        element.style.transform = `translateY(${yPos}px)`;
    });
}

// Critical resource hints
function setupCriticalResourceHints() {
    // DNS prefetch for external resources
    const dnsPrefetchDomains = [
        'fonts.googleapis.com',
        'fonts.gstatic.com',
        'cdnjs.cloudflare.com'
    ];
    
    dnsPrefetchDomains.forEach(domain => {
        const link = document.createElement('link');
        link.rel = 'dns-prefetch';
        link.href = `//${domain}`;
        document.head.appendChild(link);
    });
    
    // Preconnect to critical domains
    const preconnectDomains = [
        'https://fonts.googleapis.com',
        'https://fonts.gstatic.com'
    ];
    
    preconnectDomains.forEach(domain => {
        const link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = domain;
        link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
    });
}

// Image compression for uploads
function compressImage(file, quality = 0.8, maxWidth = 1920, maxHeight = 1080) {
    return new Promise((resolve) => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();
        
        img.onload = function() {
            // Calculate new dimensions
            let { width, height } = img;
            
            if (width > maxWidth || height > maxHeight) {
                const ratio = Math.min(maxWidth / width, maxHeight / height);
                width *= ratio;
                height *= ratio;
            }
            
            canvas.width = width;
            canvas.height = height;
            
            // Draw and compress
            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob(resolve, 'image/jpeg', quality);
        };
        
        img.src = URL.createObjectURL(file);
    });
}

// Memory management
function setupMemoryManagement() {
    // Clean up unused resources
    window.addEventListener('beforeunload', () => {
        // Revoke object URLs
        const objectUrls = document.querySelectorAll('[data-object-url]');
        objectUrls.forEach(element => {
            URL.revokeObjectURL(element.dataset.objectUrl);
        });
        
        // Clear large data structures
        if (window.currentImage) {
            window.currentImage = null;
        }
        if (window.processedImage) {
            window.processedImage = null;
        }
    });
    
    // Monitor memory usage
    if ('memory' in performance) {
        setInterval(() => {
            const memInfo = performance.memory;
            if (memInfo.usedJSHeapSize / memInfo.totalJSHeapSize > 0.9) {
                console.warn('High memory usage detected');
                // Trigger garbage collection if possible
                if (window.gc) {
                    window.gc();
                }
            }
        }, 30000);
    }
}

// Network optimization
function setupNetworkOptimization() {
    // Detect connection type
    if ('connection' in navigator) {
        const connection = navigator.connection;
        
        if (connection.effectiveType === 'slow-2g' || connection.effectiveType === '2g') {
            // Disable heavy animations and effects
            document.documentElement.classList.add('slow-connection');
            
            // Reduce image quality
            const images = document.querySelectorAll('img');
            images.forEach(img => {
                if (img.dataset.lowQuality) {
                    img.src = img.dataset.lowQuality;
                }
            });
        }
        
        // Monitor connection changes
        connection.addEventListener('change', () => {
            console.log('Connection changed:', connection.effectiveType);
        });
    }
}

// Initialize additional optimizations
setTimeout(() => {
    setupMemoryManagement();
    setupNetworkOptimization();
}, 2000);

// Export functions for use in other modules
window.performanceOptimizations = {
    compressImage,
    updateScrollAnimations,
    updateParallaxElements
};

